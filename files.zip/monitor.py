"""
Core monitor engine.

Checks a list of servers/services on a schedule and logs the results
(up/down, response time) to a local SQLite database. Supports two
check types:
  - "ping": ICMP ping, for raw IPs/hostnames (e.g. routers, internal boxes)
  - "http": HTTP(S) request, for web services/URLs (checks for a
    successful status code)

Run this as a background/scheduled process:
    python monitor.py

It will loop forever, checking all servers every CHECK_INTERVAL_SECONDS.
Stop it with Ctrl+C.
"""

import sqlite3
import subprocess
import platform
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone

import alerts

DB_PATH = "uptime.db"
CHECK_INTERVAL_SECONDS = 60  # how often to re-check all servers

# Tracks each server's last known status in memory, so we can detect
# transitions (up->down, down->up) and only alert on the change, not
# on every single check. Resets when the script restarts, which just
# means the first check after a restart won't trigger an alert (it
# takes two checks to see a "change") — acceptable for a v1.
_last_known_status = {}


def init_db():
    """Create the tables if they don't exist yet."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS servers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT NOT NULL UNIQUE,
            check_type TEXT NOT NULL DEFAULT 'ping',
            active INTEGER NOT NULL DEFAULT 1
        )
    """)

    # Migration: add check_type column if it doesn't exist yet
    # (for anyone running this against a database created before this feature)
    cur.execute("PRAGMA table_info(servers)")
    existing_columns = [row[1] for row in cur.fetchall()]
    if "check_type" not in existing_columns:
        cur.execute("ALTER TABLE servers ADD COLUMN check_type TEXT NOT NULL DEFAULT 'ping'")

    cur.execute("""
        CREATE TABLE IF NOT EXISTS checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            server_id INTEGER NOT NULL,
            timestamp TEXT NOT NULL,
            is_up INTEGER NOT NULL,
            response_time_ms REAL,
            FOREIGN KEY (server_id) REFERENCES servers (id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            server_id INTEGER NOT NULL,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            FOREIGN KEY (server_id) REFERENCES servers (id)
        )
    """)

    conn.commit()
    conn.close()


def add_server(name: str, address: str, check_type: str = "ping"):
    """
    Add a server/service to monitor. Safe to call repeatedly (ignores
    duplicates).

    check_type: "ping" for an IP/hostname, "http" for a URL
    (e.g. "https://example.com").
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO servers (name, address, check_type) VALUES (?, ?, ?)",
            (name, address, check_type),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        pass  # already exists
    finally:
        conn.close()


def get_active_servers():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, name, address, check_type FROM servers WHERE active = 1")
    rows = cur.fetchall()
    conn.close()
    return rows


def ping_host(address: str):
    """
    Ping a host using the system ping command (works cross-platform,
    no extra dependencies needed).

    Returns (is_up: bool, response_time_ms: float | None)
    """
    is_windows = platform.system().lower() == "windows"
    count_flag = "-n" if is_windows else "-c"
    timeout_flag = "-w" if is_windows else "-W"
    # Windows timeout is in ms, Linux/Mac timeout is in seconds
    timeout_value = "2000" if is_windows else "2"

    cmd = ["ping", count_flag, "1", timeout_flag, timeout_value, address]

    start = time.time()
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
        )
        elapsed_ms = (time.time() - start) * 1000
        is_up = result.returncode == 0
        return is_up, round(elapsed_ms, 1) if is_up else None
    except subprocess.TimeoutExpired:
        return False, None


def http_check(url: str, timeout_seconds: int = 5):
    """
    Check an HTTP(S) URL by making a request and checking for a
    successful status code (< 400). Uses only the standard library,
    no extra dependencies needed.

    Returns (is_up: bool, response_time_ms: float | None)
    """
    start = time.time()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "uptime-monitor/1.0"})
        with urllib.request.urlopen(req, timeout=timeout_seconds) as response:
            elapsed_ms = (time.time() - start) * 1000
            is_up = response.status < 400
            return is_up, round(elapsed_ms, 1) if is_up else None
    except urllib.error.HTTPError as e:
        # Server responded, but with an error status (4xx/5xx) — still "reachable"
        # but treated as down since the service itself isn't healthy.
        elapsed_ms = (time.time() - start) * 1000
        return False, None
    except Exception:
        # DNS failure, connection refused, timeout, etc.
        return False, None


def check_server(address: str, check_type: str):
    """Dispatch to the right check function based on check_type."""
    if check_type == "http":
        return http_check(address)
    return ping_host(address)


def log_check(server_id: int, is_up: bool, response_time_ms):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO checks (server_id, timestamp, is_up, response_time_ms)
        VALUES (?, ?, ?, ?)
        """,
        (
            server_id,
            datetime.now(timezone.utc).isoformat(),
            1 if is_up else 0,
            response_time_ms,
        ),
    )
    conn.commit()
    conn.close()


def open_incident(server_id: int, started_at: str):
    """Start a new incident record (server just went down)."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO incidents (server_id, started_at, ended_at) VALUES (?, ?, NULL)",
        (server_id, started_at),
    )
    conn.commit()
    conn.close()


def close_incident(server_id: int, ended_at: str):
    """Close the most recent open incident for this server (it recovered)."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        UPDATE incidents
        SET ended_at = ?
        WHERE id = (
            SELECT id FROM incidents
            WHERE server_id = ? AND ended_at IS NULL
            ORDER BY started_at DESC
            LIMIT 1
        )
        """,
        (ended_at, server_id),
    )
    conn.commit()
    conn.close()


def run_once():
    """Check all active servers one time and log the results."""
    servers = get_active_servers()
    if not servers:
        print("No servers configured yet. Add some with add_server().")
        return

    for server_id, name, address, check_type in servers:
        is_up, response_time_ms = check_server(address, check_type)
        log_check(server_id, is_up, response_time_ms)
        status = "UP" if is_up else "DOWN"
        rt = f"{response_time_ms} ms" if response_time_ms else "-"
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {name} ({address}, {check_type}): {status} ({rt})")

        # Alert only on a state change (not on every check), so a
        # server that's been down for an hour doesn't spam alerts
        # every 60 seconds. Also log an incident record on the same
        # transitions: opens one when a server goes down, closes the
        # matching one when it recovers.
        previous_status = _last_known_status.get(server_id)
        if previous_status is not None and previous_status != is_up:
            now = datetime.now(timezone.utc).isoformat()
            if is_up:
                close_incident(server_id, now)
            else:
                open_incident(server_id, now)
            alerts.notify_status_change(name, address, is_up)
        _last_known_status[server_id] = is_up


def run_forever():
    init_db()
    print(f"Starting uptime monitor. Checking every {CHECK_INTERVAL_SECONDS}s. Ctrl+C to stop.")
    while True:
        run_once()
        time.sleep(CHECK_INTERVAL_SECONDS)


if __name__ == "__main__":
    init_db()

    # --- Example servers to get you started. Edit these, or add more
    # via the dashboard once it's running. Safe to leave duplicates in;
    # they'll just be skipped. ---
    add_server("Google DNS", "8.8.8.8")
    add_server("Cloudflare DNS", "1.1.1.1")

    run_forever()
