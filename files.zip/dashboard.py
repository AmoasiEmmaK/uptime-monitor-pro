"""
Uptime monitor dashboard.

Run with:
    streamlit run dashboard.py

Shows current status of all monitored servers, recent history, and
uptime % over the selected time window. Also lets you add/remove
servers without editing code.
"""

import sqlite3
from datetime import datetime, timedelta, timezone

import pandas as pd
import streamlit as st

from monitor import init_db, add_server, DB_PATH

st.set_page_config(page_title="IT Uptime Monitor", layout="wide")
init_db()

st.title("🖥️ Server Uptime Monitor")
st.caption("Internal IT infrastructure health dashboard")


def get_connection():
    return sqlite3.connect(DB_PATH)


def load_servers():
    conn = get_connection()
    df = pd.read_sql_query("SELECT * FROM servers", conn)
    conn.close()
    return df


def load_latest_status():
    """Get the most recent check for each server."""
    conn = get_connection()
    query = """
        SELECT s.id, s.name, s.address, s.check_type, c.timestamp, c.is_up, c.response_time_ms
        FROM servers s
        LEFT JOIN checks c ON c.id = (
            SELECT id FROM checks
            WHERE server_id = s.id
            ORDER BY timestamp DESC
            LIMIT 1
        )
        WHERE s.active = 1
    """
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df


def load_history(server_id: int, hours: int = 24):
    conn = get_connection()
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    df = pd.read_sql_query(
        "SELECT * FROM checks WHERE server_id = ? AND timestamp >= ? ORDER BY timestamp",
        conn,
        params=(server_id, cutoff),
    )
    conn.close()
    return df


def load_incidents(limit: int = 50):
    """Load recent incidents across all servers, most recent first."""
    conn = get_connection()
    query = """
        SELECT i.id, s.name, s.address, i.started_at, i.ended_at
        FROM incidents i
        JOIN servers s ON s.id = i.server_id
        ORDER BY i.started_at DESC
        LIMIT ?
    """
    df = pd.read_sql_query(query, conn, params=(limit,))
    conn.close()
    return df


def format_duration(start_iso: str, end_iso: str | None) -> str:
    """Format the gap between two ISO timestamps as e.g. '3m 21s', or 'Ongoing' if still open."""
    if not end_iso:
        return "Ongoing"
    start = pd.to_datetime(start_iso)
    end = pd.to_datetime(end_iso)
    seconds = int((end - start).total_seconds())
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m {seconds}s"
    if minutes:
        return f"{minutes}m {seconds}s"
    return f"{seconds}s"


def uptime_percent(df: pd.DataFrame) -> float:
    if df.empty:
        return 0.0
    return round(100 * df["is_up"].sum() / len(df), 1)


# --- Sidebar: add a server ---
with st.sidebar:
    st.header("Add a server")
    with st.form("add_server_form", clear_on_submit=True):
        new_name = st.text_input("Name", placeholder="e.g. Branch Office Router")
        new_check_type = st.selectbox(
            "Check type",
            options=["ping", "http"],
            format_func=lambda t: "Ping (IP/hostname)" if t == "ping" else "HTTP (URL)",
        )
        placeholder = "e.g. 192.168.1.1" if new_check_type == "ping" else "e.g. https://intranet.inlaks.com"
        new_address = st.text_input("IP, hostname, or URL", placeholder=placeholder)
        submitted = st.form_submit_button("Add")
        if submitted and new_name and new_address:
            add_server(new_name, new_address, new_check_type)
            st.success(f"Added {new_name} ({new_address})")
            st.rerun()

    st.divider()
    hours_window = st.selectbox(
        "History window",
        options=[1, 6, 24, 72, 168],
        format_func=lambda h: f"Last {h}h" if h < 168 else "Last 7 days",
        index=2,
    )
    st.caption("Note: the monitor.py script must be running separately "
               "for new checks to be logged.")


# --- Main: current status ---
status_df = load_latest_status()

if status_df.empty:
    st.info("No servers configured yet. Add one from the sidebar.")
else:
    # --- DOWN banner: show prominently at the top if anything is down ---
    down_df = status_df[status_df["is_up"] == 0]
    if not down_df.empty:
        down_names = ", ".join(down_df["name"].tolist())
        st.error(f"🔴 {len(down_df)} server(s) currently DOWN: {down_names}", icon="🚨")
    else:
        checked_df = status_df.dropna(subset=["is_up"])
        if not checked_df.empty:
            st.success("🟢 All monitored servers are currently UP", icon="✅")

    # --- At-a-glance summary ---
    total_servers = len(status_df)
    up_count = int((status_df["is_up"] == 1).sum())
    down_count = int((status_df["is_up"] == 0).sum())
    no_data_count = int(status_df["is_up"].isna().sum())

    # Overall uptime % across all servers, over the selected window
    all_history = pd.concat(
        [load_history(row["id"], hours=hours_window) for _, row in status_df.iterrows()],
        ignore_index=True,
    ) if total_servers else pd.DataFrame(columns=["is_up"])
    overall_uptime = uptime_percent(all_history)

    summary_cols = st.columns(4)
    summary_cols[0].metric("Servers monitored", total_servers)
    summary_cols[1].metric("Up", up_count)
    summary_cols[2].metric("Down", down_count)
    summary_cols[3].metric(f"Overall uptime ({hours_window}h)", f"{overall_uptime}%")
    if no_data_count:
        st.caption(f"{no_data_count} server(s) have no data yet — waiting on monitor.py's next check cycle.")

    st.divider()
    st.subheader("Current status")
    cols = st.columns(min(len(status_df), 4) or 1)

    for i, row in status_df.iterrows():
        col = cols[i % len(cols)]
        with col:
            if pd.isna(row["is_up"]):
                st.metric(row["name"], "No data yet")
            elif row["is_up"] == 1:
                st.metric(row["name"], "🟢 UP", f"{row['response_time_ms']} ms")
            else:
                st.metric(row["name"], "🔴 DOWN")
            type_label = "🌐 HTTP" if row["check_type"] == "http" else "📡 Ping"
            st.caption(f"{row['address']} · {type_label}")

    st.divider()
    st.subheader("History & uptime %")

    for _, row in status_df.iterrows():
        history = load_history(row["id"], hours=hours_window)
        uptime = uptime_percent(history)

        with st.expander(f"{row['name']} ({row['address']}) — {uptime}% uptime"):
            if history.empty:
                st.write("No checks logged yet in this window.")
            else:
                history["timestamp"] = pd.to_datetime(history["timestamp"])
                chart_df = history.set_index("timestamp")[["is_up"]]
                st.line_chart(chart_df, height=150)

                display_df = history[["timestamp", "is_up", "response_time_ms"]].copy()
                display_df["status"] = display_df["is_up"].map({1: "UP", 0: "DOWN"})
                display_df = display_df.drop(columns=["is_up"]).sort_values(
                    "timestamp", ascending=False
                )
                st.dataframe(display_df, use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("Incident history")

    incidents_df = load_incidents(limit=50)
    if incidents_df.empty:
        st.write("No incidents recorded yet — that's a good sign.")
    else:
        table_rows = []
        for _, row in incidents_df.iterrows():
            table_rows.append({
                "Server": row["name"],
                "Address": row["address"],
                "Event": "🔴 Down" if not row["ended_at"] else "🔴 Down → 🟢 Recovered",
                "Started": pd.to_datetime(row["started_at"]).strftime("%Y-%m-%d %H:%M:%S"),
                "Duration": format_duration(row["started_at"], row["ended_at"]),
            })
        st.dataframe(pd.DataFrame(table_rows), use_container_width=True, hide_index=True)
        st.caption("Most recent incidents first, across all monitored servers.")
